from django.urls import path
from . import views


urlpatterns = [

    path(
        'signup/admin/',
        views.signup_admin,
        name='signup_admin'
    ),

    path(
        'signup/dentist/',
        views.signup_dentist,
        name='signup_dentist'
    ),

    path(
        'signup/patient/',
        views.signup_patient,
        name='signup_patient'
    ),

    path(
        'signin/',
        views.signin,
        name='signin'
    ),

    path(
        'dashboard/',
        views.dashboard,
        name='dashboard'
    ),

    path(
        'dashboard/admin/',
        views.admin_dashboard,
        name='admin_dashboard'
    ),

    path(
        'dashboard/dentist/',
        views.dentist_dashboard,
        name='dentist_dashboard'
    ),

    path(
        'dashboard/patient/',
        views.patient_dashboard,
        name='patient_dashboard'
    ),

    path(
        'logout/',
        views.signout,
        name='logout'
    ),

    path(
        'profile/',
        views.profile,
        name='profile'
    ),

    path(
        'password/forgot/',
        views.forgot_password_step1,
        name='forgot_password_step1'
    ),

    path(
        'password/forgot/verify/',
        views.forgot_password_step2,
        name='forgot_password_step2'
    ),

    path(
        'password/forgot/reset/',
        views.forgot_password_step3,
        name='forgot_password_step3'
    ),
]