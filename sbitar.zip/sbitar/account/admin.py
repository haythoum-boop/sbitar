from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


class SbitarUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'role', 'is_active', 'is_superuser')
    list_filter = ('role', 'is_active', 'is_superuser')
    fieldsets = UserAdmin.fieldsets + (
        ('Sbitar', {'fields': ('role', 'cin', 'phone')}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Sbitar', {'fields': ('email', 'role', 'cin', 'phone')}),
    )


admin.site.register(User, SbitarUserAdmin)
