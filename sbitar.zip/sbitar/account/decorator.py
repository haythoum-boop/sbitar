from functools import wraps

from django.contrib import messages
from django.shortcuts import redirect


def role_required(*roles):
    """Autorise l'accès uniquement aux utilisateurs ayant l'un des rôles donnés."""

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect('signin')

            user_role = 'admin' if request.user.is_superuser else request.user.role

            if user_role not in roles:
                messages.error(request, "Vous n'avez pas accès à cette page.")
                return redirect('dashboard')

            return view_func(request, *args, **kwargs)

        return _wrapped

    return decorator