from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.shortcuts import render, redirect

from .decorator import role_required
from .forms import (
    AdminSignUpForm,
    DentistSignUpForm,
    PatientSignUpForm,
    ForgotPasswordStep1Form,
    ForgotPasswordStep2Form,
    ForgotPasswordStep3Form,
    ProfileForm,
)
from .models import PasswordResetCode, User


def home(request):
    """Page d'accueil publique : présentation + accès rapide aux 3 espaces + stats."""

    context = {
        'total_dentists': User.objects.filter(role='dentist').count(),
        'total_patients': User.objects.filter(role='patient').count(),
        'admin_exists': User.objects.filter(role='admin').exists(),
    }
    return render(request, 'home.html', context)


def signup_admin(request):

    if request.user.is_authenticated:
        return redirect('dashboard')

    if User.objects.filter(role='admin').exists():
        messages.error(
            request,
            "Un compte admin existe déjà. Un seul admin est autorisé."
        )
        return redirect('signin')

    if request.method == 'POST':
        form = AdminSignUpForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

            messages.success(
                request,
                "Compte Admin créé avec succès."
            )

            return redirect('signin')

    else:
        form = AdminSignUpForm()

    return render(
        request,
        'account/signup.html',
        {
            'form': form,
            'account_type': 'Admin'
        }
    )


def signup_dentist(request):

    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = DentistSignUpForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

            messages.success(
                request,
                "Compte Dentist créé avec succès."
            )

            return redirect('signin')

    else:
        form = DentistSignUpForm()

    return render(
        request,
        'account/signup.html',
        {
            'form': form,
            'account_type': 'Dentist'
        }
    )


def signup_patient(request):

    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = PatientSignUpForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()

            messages.success(
                request,
                "Compte Patient créé avec succès."
            )

            return redirect('signin')

    else:
        form = PatientSignUpForm()

    return render(
        request,
        'account/signup.html',
        {
            'form': form,
            'account_type': 'Patient'
        }
    )


def signin(request):

    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('dashboard')

        messages.error(
            request,
            "Username ou mot de passe incorrect."
        )

    return render(
        request,
        'account/signin.html',
        {'admin_exists': User.objects.filter(role='admin').exists()}
    )


@login_required
def signout(request):

    logout(request)

    return redirect('signin')


@login_required
def dashboard(request):
    """Route vers le tableau de bord spécifique au rôle de l'utilisateur."""

    user = request.user

    if user.is_superuser or user.role == 'admin':
        return redirect('admin_dashboard')

    if user.role == 'dentist':
        return redirect('dentist_dashboard')

    return redirect('patient_dashboard')


@role_required('admin')
def admin_dashboard(request):
    context = {
        'total_users': User.objects.count(),
        'total_dentists': User.objects.filter(role='dentist').count(),
        'total_patients': User.objects.filter(role='patient').count(),
    }
    return render(request, 'account/dashboard_admin.html', context)


@role_required('dentist')
def dentist_dashboard(request):
    return render(request, 'account/dashboard_dentist.html')


@role_required('patient')
def patient_dashboard(request):
    return render(request, 'account/dashboard_patient.html')


@login_required
def profile(request):

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user)

        if form.is_valid():
            form.save()
            messages.success(request, "Profil mis à jour avec succès.")
            return redirect('profile')
    else:
        form = ProfileForm(instance=request.user)

    return render(request, 'account/profile.html', {'form': form})


# ---------------------------------------------------------------------------
# Mot de passe oublié — flux en 3 étapes
#
# 1) L'utilisateur saisit son email + CIN -> comparaison en base.
# 2) Si ça correspond, un code aléatoire à 6 chiffres est généré et envoyé
#    par email. L'utilisateur le saisit pour prouver son identité.
# 3) L'utilisateur choisit un nouveau mot de passe.
# ---------------------------------------------------------------------------

def forgot_password_step1(request):

    if request.method == 'POST':
        form = ForgotPasswordStep1Form(request.POST)

        if form.is_valid():
            user = form.cleaned_data['user']

            reset_code = PasswordResetCode.objects.create(
                user=user,
                code=PasswordResetCode.generate_code()
            )

            send_mail(
                subject="Sbitar - Code de réinitialisation du mot de passe",
                message=(
                    f"Bonjour {user.username},\n\n"
                    f"Votre code de vérification est : {reset_code.code}\n"
                    f"Ce code est valable {settings.PASSWORD_RESET_CODE_VALIDITY_MINUTES} minutes.\n\n"
                    "Si vous n'êtes pas à l'origine de cette demande, ignorez cet email."
                ),
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=True,
            )

            request.session['reset_user_id'] = user.id
            request.session['reset_verified'] = False

            messages.success(
                request,
                "Un code de vérification a été envoyé à votre adresse email."
            )

            if settings.DEBUG:
                messages.info(
                    request,
                    f"[Mode développement] Votre code est : {reset_code.code}"
                )

            return redirect('forgot_password_step2')
    else:
        form = ForgotPasswordStep1Form()

    return render(request, 'account/forgot_password_step1.html', {'form': form})


def forgot_password_step2(request):

    user_id = request.session.get('reset_user_id')

    if not user_id:
        messages.error(request, "Veuillez d'abord renseigner votre email et CIN.")
        return redirect('forgot_password_step1')

    if request.method == 'POST':
        form = ForgotPasswordStep2Form(request.POST)

        if form.is_valid():
            code = form.cleaned_data['code']

            reset_code = PasswordResetCode.objects.filter(
                user_id=user_id,
                code=code,
                is_used=False,
            ).order_by('-created_at').first()

            if reset_code and reset_code.is_valid():
                reset_code.is_used = True
                reset_code.save(update_fields=['is_used'])

                request.session['reset_verified'] = True

                messages.success(request, "Code vérifié. Choisissez votre nouveau mot de passe.")
                return redirect('forgot_password_step3')

            messages.error(request, "Code invalide ou expiré.")
    else:
        form = ForgotPasswordStep2Form()

    return render(request, 'account/forgot_password_step2.html', {'form': form})


def forgot_password_step3(request):

    user_id = request.session.get('reset_user_id')
    verified = request.session.get('reset_verified')

    if not user_id or not verified:
        messages.error(request, "Veuillez d'abord vérifier votre code.")
        return redirect('forgot_password_step1')

    user = User.objects.filter(id=user_id).first()

    if not user:
        messages.error(request, "Utilisateur introuvable.")
        return redirect('forgot_password_step1')

    if request.method == 'POST':
        form = ForgotPasswordStep3Form(request.POST)

        if form.is_valid():
            user.set_password(form.cleaned_data['new_password1'])
            user.save()

            del request.session['reset_user_id']
            del request.session['reset_verified']

            messages.success(
                request,
                "Votre mot de passe a été réinitialisé avec succès. Vous pouvez vous connecter."
            )
            return redirect('signin')
    else:
        form = ForgotPasswordStep3Form()

    return render(request, 'account/forgot_password_step3.html', {'form': form})