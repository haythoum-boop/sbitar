import random

from django.conf import settings
from django.contrib.auth.models import AbstractUser, UserManager
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class SbitarUserManager(UserManager):
    """Manager qui force le compte créé via createsuperuser à être l'admin unique."""

    def create_superuser(self, username, email=None, password=None, **extra_fields):

        if not email or not email.lower().endswith('@admin.nat.tn'):
            raise ValueError(
                "L'email de l'admin doit se terminer par @admin.nat.tn"
            )

        extra_fields.setdefault('role', 'admin')
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return super().create_superuser(username, email, password, **extra_fields)


class User(AbstractUser):

    ROLE_CHOICES = (
        ('dentist', 'Dentist'),
        ('patient', 'Patient'),
        ('admin', 'Admin'),
    )

    email = models.EmailField(unique=True)

    cin = models.CharField(
        max_length=8,
        unique=True
    )

    phone = models.CharField(max_length=20, blank=True)

    profile_picture = models.ImageField(
        upload_to='profiles/',
        blank=True,
        null=True
    )

    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='patient'
    )

    objects = SbitarUserManager()

    REQUIRED_FIELDS = ['email', 'cin']

    def __str__(self):
        return f"{self.username} - {self.role}"

    def is_admin_role(self):
        return self.role == 'admin' or self.is_superuser

    def is_dentist(self):
        return self.role == 'dentist'

    def is_patient(self):
        return self.role == 'patient'

    def clean(self):
        super().clean()

        if self.role == 'admin':
            if not self.email or not self.email.lower().endswith('@admin.nat.tn'):
                raise ValidationError(
                    {'email': "L'email de l'admin doit se terminer par @admin.nat.tn"}
                )

            already_exists = User.objects.filter(role='admin').exclude(pk=self.pk).exists()

            if already_exists:
                raise ValidationError("Un seul compte admin est autorisé.")

    def save(self, *args, **kwargs):
        if self.role == 'admin':
            if not self.email or not self.email.lower().endswith('@admin.nat.tn'):
                raise ValidationError(
                    "L'email de l'admin doit se terminer par @admin.nat.tn"
                )

            already_exists = User.objects.filter(role='admin').exclude(pk=self.pk).exists()

            if already_exists:
                raise ValidationError("Un seul compte admin est autorisé.")

        super().save(*args, **kwargs)


class PasswordResetCode(models.Model):
    """Code à 6 chiffres généré pour la réinitialisation du mot de passe."""

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reset_codes'
    )
    code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - {self.code}"

    @staticmethod
    def generate_code():
        return f"{random.randint(0, 999999):06d}"

    def is_expired(self):
        validity = getattr(settings, 'PASSWORD_RESET_CODE_VALIDITY_MINUTES', 15)
        return (timezone.now() - self.created_at).total_seconds() > validity * 60

    def is_valid(self):
        return not self.is_used and not self.is_expired()