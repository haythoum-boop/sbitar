from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.password_validation import validate_password

from .models import User


class BootstrapFormMixin:
    """Ajoute automatiquement la classe Bootstrap 'form-control' à chaque champ."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields.values():
            widget = field.widget

            if isinstance(widget, (forms.CheckboxInput,)):
                existing = widget.attrs.get('class', '')
                widget.attrs['class'] = (existing + ' form-check-input').strip()
            else:
                existing = widget.attrs.get('class', '')
                widget.attrs['class'] = (existing + ' form-control').strip()


class DentistSignUpForm(BootstrapFormMixin, UserCreationForm):

    email = forms.EmailField()
    username = forms.CharField(max_length=150)
    cin = forms.CharField(max_length=8)
    profile_picture = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'cin',
            'profile_picture',
            'password1',
            'password2'
        ]

    def clean_email(self):
        email = self.cleaned_data['email'].lower()

        if not email.endswith('@dentalcare.nat.tn'):
            raise forms.ValidationError(
                "L'email doit se terminer par @dentalcare.nat.tn"
            )

        return email

    def clean_cin(self):
        cin = self.cleaned_data['cin']

        if len(cin) != 8 or not cin.isdigit():
            raise forms.ValidationError(
                "Le CIN doit contenir exactement 8 chiffres."
            )

        return cin

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = 'dentist'
        user.profile_picture = self.cleaned_data.get('profile_picture')

        if commit:
            user.save()

        return user


class AdminSignUpForm(BootstrapFormMixin, UserCreationForm):

    email = forms.EmailField()
    username = forms.CharField(max_length=150)
    cin = forms.CharField(max_length=8)
    profile_picture = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'cin',
            'profile_picture',
            'password1',
            'password2'
        ]

    def clean_email(self):
        email = self.cleaned_data['email'].lower()

        if not email.endswith('@admin.nat.tn'):
            raise forms.ValidationError(
                "L'email doit se terminer par @admin.nat.tn"
            )

        return email

    def clean_cin(self):
        cin = self.cleaned_data['cin']

        if len(cin) != 8 or not cin.isdigit():
            raise forms.ValidationError(
                "Le CIN doit contenir exactement 8 chiffres."
            )

        return cin

    def clean(self):
        cleaned_data = super().clean()

        if User.objects.filter(role='admin').exists():
            raise forms.ValidationError(
                "Un compte admin existe déjà. Un seul admin est autorisé."
            )

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = 'admin'
        user.is_staff = True
        user.profile_picture = self.cleaned_data.get('profile_picture')

        if commit:
            user.save()

        return user


class PatientSignUpForm(BootstrapFormMixin, UserCreationForm):

    email = forms.EmailField()
    username = forms.CharField(max_length=150)
    cin = forms.CharField(max_length=8)
    profile_picture = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = [
            'username',
            'email',
            'cin',
            'profile_picture',
            'password1',
            'password2'
        ]

    def clean_cin(self):
        cin = self.cleaned_data['cin']

        if len(cin) != 8 or not cin.isdigit():
            raise forms.ValidationError(
                "Le CIN doit contenir exactement 8 chiffres."
            )

        return cin

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = 'patient'
        user.profile_picture = self.cleaned_data.get('profile_picture')

        if commit:
            user.save()

        return user

class ForgotPasswordStep1Form(BootstrapFormMixin, forms.Form):
    """Étape 1 : le champ texte email + CIN comparé à la base."""

    email = forms.EmailField(label="Adresse email")
    cin = forms.CharField(label="CIN", max_length=8)

    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get('email', '').lower()
        cin = cleaned_data.get('cin')

        user = User.objects.filter(email__iexact=email, cin=cin).first()

        if not user:
            raise forms.ValidationError(
                "Aucun compte ne correspond à cet email et ce CIN."
            )

        cleaned_data['user'] = user
        return cleaned_data


class ForgotPasswordStep2Form(BootstrapFormMixin, forms.Form):
    """Étape 2 : saisie du code aléatoire reçu."""

    code = forms.CharField(
        label="Code de vérification",
        max_length=6,
        min_length=6
    )


class ForgotPasswordStep3Form(BootstrapFormMixin, forms.Form):
    """Étape 3 : nouveau mot de passe."""

    new_password1 = forms.CharField(
        label="Nouveau mot de passe",
        widget=forms.PasswordInput
    )
    new_password2 = forms.CharField(
        label="Confirmer le mot de passe",
        widget=forms.PasswordInput
    )

    def clean_new_password1(self):
        password = self.cleaned_data['new_password1']
        validate_password(password)
        return password

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get('new_password1')
        p2 = cleaned_data.get('new_password2')

        if p1 and p2 and p1 != p2:
            raise forms.ValidationError("Les deux mots de passe ne correspondent pas.")

        return cleaned_data


class ProfileForm(BootstrapFormMixin, forms.ModelForm):

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone', 'profile_picture']