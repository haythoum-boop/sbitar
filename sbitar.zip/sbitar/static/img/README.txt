Images utilisées par la page d'accueil (templates/home.html) :

- hero-poster.jpg       -> image affichée en fallback/pendant le chargement de la vidéo hero
- partner-1.png         -> logo du 1er partenaire solidaire
- partner-2.png         -> logo du 2e partenaire solidaire
- partner-3.png         -> logo du 3e partenaire solidaire
- team-1.jpg .. team-4.jpg -> photos des 4 personnes ("Développé par")

Tant qu'un fichier n'est pas présent, la page affiche automatiquement un
placeholder propre (cadre en pointillés "Logo X" pour les partenaires,
icône 🧑‍💻 pour l'équipe), donc rien ne casse si les images manquent.
Il suffit de déposer les vrais fichiers ici avec exactement ces noms, et
de mettre à jour les noms/rôles dans templates/home.html (recherchez
"Nom Prénom" et "Développeur").
