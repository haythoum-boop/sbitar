Put your background video here as: hero.mp4
(short, muted, looping clip - e.g. clinic interior, smiling patient, etc.)
If no file is present, the hero still looks good thanks to the CSS gradient background.
