document.addEventListener('DOMContentLoaded', function () {
    var dentistField = document.getElementById('id_dentist');
    var dateField = document.getElementById('id_date');
    var timeField = document.getElementById('id_start_time');
    var messageBox = document.getElementById('slot-message');

    if (!dentistField || !dateField || !timeField || !window.AVAILABLE_SLOTS_URL) {
        return;
    }

    function placeholderOption() {
        var opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '— Choisir un créneau —';
        return opt;
    }

    function resetTimeField(message) {
        timeField.innerHTML = '';
        timeField.appendChild(placeholderOption());
        timeField.disabled = true;

        if (messageBox) {
            messageBox.textContent = message || '';
        }
    }

    function loadSlots() {
        var dentistId = dentistField.value;
        var date = dateField.value;

        if (!dentistId || !date) {
            resetTimeField('Choisissez un dentiste et une date pour voir les créneaux disponibles.');
            return;
        }

        resetTimeField('Chargement des créneaux...');

        var url = window.AVAILABLE_SLOTS_URL
            + '?dentist_id=' + encodeURIComponent(dentistId)
            + '&date=' + encodeURIComponent(date);

        fetch(url)
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (data.error) {
                    resetTimeField('');
                    if (messageBox) {
                        messageBox.textContent = data.error;
                    }
                    return;
                }

                if (data.past) {
                    resetTimeField('');
                    if (messageBox) {
                        messageBox.textContent = "Cette date est déjà passée, choisissez une date à partir d'aujourd'hui.";
                    }
                    return;
                }

                if (data.day_complete) {
                    resetTimeField('');
                    alert('Journée complète pour ce dentiste, merci de choisir une autre date.');
                    return;
                }

                timeField.innerHTML = '';
                timeField.appendChild(placeholderOption());

                data.slots.forEach(function (slot) {
                    var opt = document.createElement('option');
                    opt.value = slot.value;
                    opt.textContent = slot.label;
                    timeField.appendChild(opt);
                });

                timeField.disabled = false;

                if (messageBox) {
                    messageBox.textContent = data.slots.length + ' créneau(x) disponible(s).';
                }
            })
            .catch(function () {
                if (messageBox) {
                    messageBox.textContent = 'Impossible de charger les créneaux, réessayez.';
                }
            });
    }

    dentistField.addEventListener('change', loadSlots);
    dateField.addEventListener('change', loadSlots);

    resetTimeField('Choisissez un dentiste et une date pour voir les créneaux disponibles.');

    // Cas de la création manuelle par un dentiste : le champ dentiste n'a
    // qu'une seule option (lui-même), déjà sélectionnée au chargement.
    if (dentistField.value && dateField.value) {
        loadSlots();
    }
});
