from datetime import timedelta

from django.conf import settings
from django.db import models
from django.utils import timezone


class Appointment(models.Model):

    STATUS_PENDING = 'pending'
    STATUS_CONFIRMED = 'confirmed'
    STATUS_CANCELLED = 'cancelled'

    STATUS_CHOICES = (
        (STATUS_PENDING, 'En attente'),
        (STATUS_CONFIRMED, 'Confirmé'),
        (STATUS_CANCELLED, 'Annulé'),
    )

    dentist = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='appointments_as_dentist',
        limit_choices_to={'role': 'dentist'},
    )

    patient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='appointments_as_patient',
        limit_choices_to={'role': 'patient'},
    )

    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()

    reason = models.CharField(max_length=255, blank=True)

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
    )

    # Un rendez-vous créé directement par un admin/dentiste (secrétariat, walk-in)
    # est considéré confirmé d'emblée plutôt qu'en attente.
    created_by_staff = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['date', 'start_time']

    def __str__(self):
        return f"{self.patient} - Dr. {self.dentist} - {self.date} {self.start_time}"

    def is_past(self):
        now = timezone.localtime()
        if self.date < now.date():
            return True
        if self.date == now.date() and self.start_time < now.time():
            return True
        return False

    def can_be_cancelled(self):
        return self.status in (self.STATUS_PENDING, self.STATUS_CONFIRMED) and not self.is_past()

    @staticmethod
    def auto_confirm_stale():
        """Confirme automatiquement les demandes en attente depuis plus de 24h
        (le patient avait ce délai pour annuler ; passé ce délai, le RDV est
        considéré comme accepté même si le dentiste n'a pas cliqué "Confirmer")."""

        threshold = timezone.now() - timedelta(hours=24)
        Appointment.objects.filter(
            status=Appointment.STATUS_PENDING,
            created_at__lte=threshold,
        ).update(status=Appointment.STATUS_CONFIRMED)
