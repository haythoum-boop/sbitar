from django.urls import path

from . import views

urlpatterns = [

    path(
        'rdv/reserver/',
        views.reserve_appointment,
        name='reserve_appointment'
    ),

    path(
        'rdv/creneaux-disponibles/',
        views.available_slots,
        name='available_slots'
    ),

    path(
        'rdv/creer-manuel/',
        views.manual_create_appointment,
        name='manual_create_appointment'
    ),

    path(
        'rdv/<int:appointment_id>/confirmer/',
        views.confirm_appointment,
        name='confirm_appointment'
    ),

    path(
        'rdv/<int:appointment_id>/annuler/',
        views.cancel_appointment,
        name='cancel_appointment'
    ),
]
