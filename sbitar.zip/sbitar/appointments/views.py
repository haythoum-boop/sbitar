from datetime import datetime

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from account.decorator import role_required

from .forms import ManualAppointmentForm, ReservationForm
from .models import Appointment
from .slots import generate_daily_slots

User = get_user_model()


@role_required('patient')
def reserve_appointment(request):
    """Le patient choisit un dentiste, une date, un créneau libre et un motif."""

    Appointment.auto_confirm_stale()

    if request.method == 'POST':
        form = ReservationForm(request.POST)

        if form.is_valid():
            Appointment.objects.create(
                dentist=form.cleaned_data['dentist'],
                patient=request.user,
                date=form.cleaned_data['date'],
                start_time=form.cleaned_data['start_time'],
                end_time=form.cleaned_data['end_time'],
                reason=form.cleaned_data['reason'],
                status=Appointment.STATUS_PENDING,
            )

            messages.success(
                request,
                "Votre demande de rendez-vous a été envoyée. Elle sera confirmée par le "
                "dentiste, ou automatiquement sous 24h si vous ne l'annulez pas."
            )
            return redirect('dashboard')
    else:
        form = ReservationForm()

    return render(request, 'appointments/reserve.html', {'form': form})


def available_slots(request):
    """Endpoint JSON interrogé en AJAX par le formulaire (patient et création manuelle)."""

    dentist_id = request.GET.get('dentist_id')
    date_str = request.GET.get('date')

    if not dentist_id or not date_str:
        return JsonResponse({'error': 'Paramètres manquants.'}, status=400)

    try:
        selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({'error': 'Date invalide.'}, status=400)

    now = timezone.localtime()

    if selected_date < now.date():
        return JsonResponse({'slots': [], 'day_complete': False, 'past': True})

    taken = set(
        Appointment.objects.filter(
            dentist_id=dentist_id,
            date=selected_date,
            status__in=[Appointment.STATUS_PENDING, Appointment.STATUS_CONFIRMED],
        ).values_list('start_time', flat=True)
    )

    all_slots = generate_daily_slots()

    available = []
    for start, end in all_slots:
        if start in taken:
            continue
        # Si c'est aujourd'hui, on masque aussi les créneaux déjà passés.
        if selected_date == now.date() and start <= now.time():
            continue
        available.append((start, end))

    data = {
        'slots': [
            {'value': start.strftime('%H:%M'), 'label': f"{start.strftime('%H:%M')} - {end.strftime('%H:%M')}"}
            for start, end in available
        ],
        'day_complete': len(available) == 0,
        'past': False,
    }
    return JsonResponse(data)


@role_required('admin', 'dentist')
def manual_create_appointment(request):
    """Création manuelle d'un rendez-vous (secrétariat/admin ou dentiste) — confirmé directement."""

    Appointment.auto_confirm_stale()

    is_dentist = request.user.role == 'dentist' and not request.user.is_superuser

    if request.method == 'POST':
        form = ManualAppointmentForm(request.POST)

        if is_dentist:
            form.fields['dentist'].queryset = User.objects.filter(pk=request.user.pk)

        if form.is_valid():
            dentist = form.cleaned_data['dentist']

            if is_dentist and dentist.pk != request.user.pk:
                messages.error(request, "Vous ne pouvez créer un rendez-vous que dans votre propre agenda.")
            else:
                Appointment.objects.create(
                    dentist=dentist,
                    patient=form.cleaned_data['patient'],
                    date=form.cleaned_data['date'],
                    start_time=form.cleaned_data['start_time'],
                    end_time=form.cleaned_data['end_time'],
                    reason=form.cleaned_data['reason'],
                    status=Appointment.STATUS_CONFIRMED,
                    created_by_staff=True,
                )
                messages.success(request, "Rendez-vous créé et confirmé avec succès.")
                return redirect('dashboard')
    else:
        form = ManualAppointmentForm()

        if is_dentist:
            form.fields['dentist'].queryset = User.objects.filter(pk=request.user.pk)
            form.fields['dentist'].initial = request.user.pk

    return render(request, 'appointments/manual_create.html', {'form': form})


@role_required('dentist')
def confirm_appointment(request, appointment_id):
    """Seul le dentiste concerné peut confirmer un rendez-vous en attente."""

    appointment = get_object_or_404(Appointment, pk=appointment_id, dentist=request.user)

    if request.method == 'POST':
        if appointment.status == Appointment.STATUS_PENDING:
            appointment.status = Appointment.STATUS_CONFIRMED
            appointment.save(update_fields=['status', 'updated_at'])
            messages.success(request, "Rendez-vous confirmé.")
        else:
            messages.info(request, "Ce rendez-vous n'est plus en attente de confirmation.")

    return redirect('dashboard')


@role_required('patient', 'dentist')
def cancel_appointment(request, appointment_id):
    """Le patient annule son propre RDV ; le dentiste peut annuler ceux de son agenda."""

    if request.user.role == 'dentist':
        appointment = get_object_or_404(Appointment, pk=appointment_id, dentist=request.user)
    else:
        appointment = get_object_or_404(Appointment, pk=appointment_id, patient=request.user)

    if request.method == 'POST':
        if appointment.can_be_cancelled():
            appointment.status = Appointment.STATUS_CANCELLED
            appointment.save(update_fields=['status', 'updated_at'])
            messages.success(request, "Rendez-vous annulé.")
        else:
            messages.error(request, "Ce rendez-vous ne peut plus être annulé.")

    return redirect('dashboard')
