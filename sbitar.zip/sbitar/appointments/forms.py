from datetime import datetime

from django import forms
from django.contrib.auth import get_user_model
from django.utils import timezone

from account.forms import BootstrapFormMixin

from .models import Appointment
from .slots import slot_choices, slot_end_for_start

User = get_user_model()


class BaseAppointmentForm(BootstrapFormMixin, forms.Form):
    """Champs communs : date + créneau, avec double validation (format + disponibilité)."""

    date = forms.DateField(
        label="Date",
        widget=forms.DateInput(attrs={'type': 'date'}),
    )
    start_time = forms.ChoiceField(
        label="Créneau horaire",
        choices=[],
        help_text="Rempli automatiquement selon le dentiste et la date choisis.",
    )
    reason = forms.CharField(
        label="Motif de la consultation",
        widget=forms.Textarea(attrs={'rows': 3}),
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Sert de secours si le JS est désactivé ; la vraie liste filtrée
        # (créneaux déjà pris exclus) est chargée dynamiquement côté client.
        self.fields['start_time'].choices = slot_choices()
        self.fields['date'].widget.attrs['min'] = timezone.localdate().isoformat()

    def clean_date(self):
        selected_date = self.cleaned_data['date']

        if selected_date < timezone.localdate():
            raise forms.ValidationError("La date ne peut pas être dans le passé.")

        return selected_date

    def clean_start_time(self):
        value = self.cleaned_data['start_time']

        try:
            start_time = datetime.strptime(value, '%H:%M').time()
        except ValueError:
            raise forms.ValidationError("Créneau invalide.")

        end_time = slot_end_for_start(start_time)

        if end_time is None:
            raise forms.ValidationError("Ce créneau n'existe pas.")

        self.cleaned_data['end_time'] = end_time
        return start_time

    def _check_slot_conflict(self, cleaned_data):
        dentist = cleaned_data.get('dentist')
        selected_date = cleaned_data.get('date')
        start_time = cleaned_data.get('start_time')

        if dentist and selected_date and start_time:
            conflict = Appointment.objects.filter(
                dentist=dentist,
                date=selected_date,
                start_time=start_time,
                status__in=[Appointment.STATUS_PENDING, Appointment.STATUS_CONFIRMED],
            ).exists()

            if conflict:
                raise forms.ValidationError(
                    "Ce créneau vient d'être réservé (par vous ou un autre patient). "
                    "Merci d'en choisir un autre."
                )

        return cleaned_data


class ReservationForm(BaseAppointmentForm):
    """Formulaire de réservation utilisé par le patient."""

    dentist = forms.ModelChoiceField(
        queryset=User.objects.filter(role='dentist').order_by('username'),
        label="Dentiste",
        empty_label="— Choisir un dentiste —",
    )

    field_order = ['dentist', 'date', 'start_time', 'reason']

    def clean(self):
        cleaned_data = super().clean()
        return self._check_slot_conflict(cleaned_data)


class ManualAppointmentForm(BaseAppointmentForm):
    """Formulaire de création manuelle (admin ou dentiste, ex: rendez-vous par téléphone)."""

    patient = forms.ModelChoiceField(
        queryset=User.objects.filter(role='patient').order_by('username'),
        label="Patient",
        empty_label="— Choisir un patient —",
    )
    dentist = forms.ModelChoiceField(
        queryset=User.objects.filter(role='dentist').order_by('username'),
        label="Dentiste",
        empty_label="— Choisir un dentiste —",
    )

    field_order = ['patient', 'dentist', 'date', 'start_time', 'reason']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['reason'].required = False

    def clean(self):
        cleaned_data = super().clean()
        return self._check_slot_conflict(cleaned_data)
