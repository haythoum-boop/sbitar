from django.contrib import admin

from .models import Appointment


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('date', 'start_time', 'end_time', 'dentist', 'patient', 'status', 'created_by_staff')
    list_filter = ('status', 'dentist', 'date', 'created_by_staff')
    search_fields = ('patient__username', 'dentist__username', 'reason')
    date_hierarchy = 'date'
