"""Génération des créneaux horaires du cabinet.

Créneaux de 30 minutes avec 5 minutes de battement entre chaque, de 9h00
à 17h00 : 09:00-09:30, 09:35-10:05, 10:10-10:40, ... jusqu'à 17h00.
"""

from datetime import date, datetime, time, timedelta

DAY_START = time(9, 0)
DAY_END = time(17, 0)
SLOT_DURATION_MINUTES = 30
SLOT_GAP_MINUTES = 5


def generate_daily_slots():
    """Retourne la liste des créneaux (heure_debut, heure_fin) de la journée."""

    reference_day = date(2000, 1, 1)  # jour bidon, seule l'heure nous intéresse
    current = datetime.combine(reference_day, DAY_START)
    end_of_day = datetime.combine(reference_day, DAY_END)
    step = timedelta(minutes=SLOT_DURATION_MINUTES + SLOT_GAP_MINUTES)
    duration = timedelta(minutes=SLOT_DURATION_MINUTES)

    slots = []
    while current + duration <= end_of_day:
        slots.append((current.time(), (current + duration).time()))
        current += step

    return slots


def slot_choices():
    """Choix pour un champ de formulaire Django : [("09:00", "09:00 - 09:30"), ...]"""

    return [
        (start.strftime('%H:%M'), f"{start.strftime('%H:%M')} - {end.strftime('%H:%M')}")
        for start, end in generate_daily_slots()
    ]


def slot_end_for_start(start_time):
    """Retourne l'heure de fin correspondant à une heure de début donnée, ou None."""

    for start, end in generate_daily_slots():
        if start == start_time:
            return end

    return None
